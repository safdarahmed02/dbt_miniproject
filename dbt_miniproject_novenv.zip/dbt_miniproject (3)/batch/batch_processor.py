#!/usr/bin/env python3
"""
Batch Processing Job
Runs the same aggregations as the streaming job but on the full dataset.
Scheduled to run nightly at 23:55 IST.
"""
import os
import time
import logging
from datetime import datetime, timedelta
import sys
import psutil

from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, window, count, avg, explode, 
    split, length, expr, to_timestamp, regexp_extract,
    current_timestamp, lit, date_add
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# MySQL configuration
MYSQL_URL = "jdbc:mysql://localhost:3306/dbt_analytics"
MYSQL_PROPERTIES = {
    "user": "dbt_user",
    "password": "dbt_password",
    "driver": "com.mysql.cj.jdbc.Driver"
}

# Define 20-minute window duration (same as streaming job)
WINDOW_DURATION = 20

def create_spark_session():
    """Create and configure Spark Session with necessary packages."""
    return (SparkSession.builder
            .appName("TweetBatchAnalytics")
            .master("local[*]")
            .config("spark.jars.packages", "mysql:mysql-connector-java:8.0.33")
            .getOrCreate())

def process_batch_data(spark):
    """Process all data in batch mode, mimicking the same aggregations as streaming."""
    start_time = time.time()
    start_cpu = psutil.cpu_percent()
    start_memory = psutil.virtual_memory().percent
    
    try:
        # Read raw tweets from MySQL
        tweets_df = (spark.read
                    .jdbc(
                        url=MYSQL_URL,
                        table="tweet_raw",
                        properties=MYSQL_PROPERTIES
                    ))
        
        logger.info(f"Loaded {tweets_df.count()} tweets from MySQL")
        
        # Show a sample tweet for debugging
        logger.info("Sample tweet data:")
        tweets_df.select("text").limit(1).show(truncate=False)
        
        # Filter for English tweets (same as streaming job)
        english_tweets = tweets_df.filter(col("lang") == "en")
        
        # Extract hashtags directly from text
        # Look for #word pattern in the text
        english_tweets = english_tweets.withColumn(
            "extracted_hashtags", 
            expr("regexp_extract_all(text, '#(\\\\w+)', 1)")  # Need to escape backslash for regex
        )
        
        # Show extracted hashtags
        logger.info("Sample extracted hashtags:")
        english_tweets.select("text", "extracted_hashtags").limit(1).show(truncate=False)
        
        # Explode hashtags array to get one row per hashtag
        hashtag_df = (english_tweets
            .select(
                col("tweet_id"),
                col("created_at"),
                explode(col("extracted_hashtags")).alias("hashtag"),
                length(col("text")).alias("text_length")
            )
            .filter(col("hashtag") != "")
        )
        
        # Show exploded hashtags
        logger.info("Sample exploded hashtags:")
        hashtag_df.limit(5).show()
        
        # Define a 20-minute window function
        windowed_stats = (hashtag_df
            .withColumn("window_start", expr("date_trunc('minute', created_at) - (minute(created_at) % 20) * interval 1 minute"))
            .groupBy(col("window_start"), col("hashtag"))
            .agg(
                count("*").alias("cnt"),
                avg("text_length").alias("avg_len")
            )
        )
        
        # Add window end and run date
        result_df = (windowed_stats
            .withColumn("window_end", expr("window_start + interval 20 minute"))
            .withColumn("run_date", current_timestamp())
            .select(
                col("window_start"),
                col("window_end"),
                col("hashtag"),
                col("cnt"),
                col("avg_len"),
                col("run_date")
            )
        )
        
        # Show window results
        logger.info("Sample windowed results:")
        result_df.limit(5).show()
        
        # Write results to MySQL
        (result_df.write
            .jdbc(
                url=MYSQL_URL,
                table="batch_window_stats",
                mode="overwrite",  # Overwrite previous batch results
                properties=MYSQL_PROPERTIES
            ))
        
        # Calculate metrics
        elapsed_time = time.time() - start_time
        end_cpu = psutil.cpu_percent()
        end_memory = psutil.virtual_memory().percent
        
        # Log performance metrics
        logger.info(f"Batch job completed in {elapsed_time:.2f} seconds")
        logger.info(f"CPU usage: {start_cpu:.1f}% -> {end_cpu:.1f}%")
        logger.info(f"Memory usage: {start_memory:.1f}% -> {end_memory:.1f}%")
        logger.info(f"Processed {result_df.count()} aggregated records")
        
        return True
        
    except Exception as e:
        logger.error(f"Error in batch processing: {e}")
        return False

def main():
    """Main entry point for the batch processing job."""
    logger.info("Starting batch processing job")
    
    spark = create_spark_session()
    
    try:
        success = process_batch_data(spark)
        if success:
            logger.info("Batch processing completed successfully")
        else:
            logger.error("Batch processing failed")
            sys.exit(1)
    finally:
        spark.stop()

if __name__ == "__main__":
    main() 