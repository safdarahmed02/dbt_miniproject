#!/usr/bin/env python3
"""
Scheduler for the batch processing job.
Runs the batch job every day at 23:55 IST.
"""
import time
import logging
import os
import sys
import subprocess
import schedule
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Path to the batch processor script
BATCH_SCRIPT = os.path.join(os.path.dirname(__file__), "batch_processor.py")

def run_batch_job():
    """Run the batch processing job."""
    logger.info(f"Scheduled batch job starting at {datetime.now().isoformat()}")
    
    try:
        # Run the batch processing script
        process = subprocess.Popen(
            ["python3", BATCH_SCRIPT],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        # Wait for the process to complete
        stdout, stderr = process.communicate()
        
        # Log the output
        if process.returncode == 0:
            logger.info("Batch job completed successfully")
            logger.debug(f"Output: {stdout.decode()}")
        else:
            logger.error(f"Batch job failed with code {process.returncode}")
            logger.error(f"Error: {stderr.decode()}")
    
    except Exception as e:
        logger.error(f"Error running batch job: {e}")

def main():
    """Main entry point for the scheduler."""
    logger.info("Starting batch job scheduler")
    
    # Schedule the batch job to run at 23:55 every day
    schedule.every().day.at("23:55").do(run_batch_job)
    
    logger.info("Scheduler is running, batch job will run at 23:55 IST daily")
    
    # Run once immediately for testing purposes
    logger.info("Running batch job immediately for testing...")
    run_batch_job()
    
    try:
        # Keep the scheduler running
        while True:
            schedule.run_pending()
            time.sleep(60)  # Check every minute
    
    except KeyboardInterrupt:
        logger.info("Scheduler stopped by user")
    except Exception as e:
        logger.error(f"Error in scheduler: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main() 