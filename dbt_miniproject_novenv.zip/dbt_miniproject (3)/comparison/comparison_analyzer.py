#!/usr/bin/env python3
"""
Comparison Analyzer
Compares the results from streaming and batch processing to calculate accuracy and performance metrics.
Outputs CSV report and generates charts for visualization.
"""
import os
import sys
import logging
import time
import json
import pandas as pd
import matplotlib.pyplot as plt
import mysql.connector
from datetime import datetime, timedelta

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# MySQL configuration
MYSQL_CONFIG = {
    "host": os.getenv("MYSQL_HOST", "localhost"),
    "port": int(os.getenv("MYSQL_PORT", 3306)),
    "user": os.getenv("MYSQL_USER", "dbt_user"),
    "password": os.getenv("MYSQL_PASSWORD", "dbt_password"),
    "database": os.getenv("MYSQL_DATABASE", "dbt_analytics")
}

# Output directory for reports and charts
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "output")
os.makedirs(OUTPUT_DIR, exist_ok=True)

def connect_to_mysql():
    """Connect to MySQL database."""
    try:
        conn = mysql.connector.connect(**MYSQL_CONFIG)
        logger.info("Connected to MySQL database")
        return conn
    except Exception as e:
        logger.error(f"Error connecting to MySQL: {e}")
        sys.exit(1)

def get_comparison_data(conn):
    """
    Fetch and compare data from streaming and batch tables.
    Returns a DataFrame with comparison metrics.
    """
    try:
        cursor = conn.cursor(dictionary=True)
        
        # Query to join streaming and batch results and calculate differences
        query = """
        SELECT 
            s.window_start,
            s.hashtag,
            s.cnt AS cnt_stream,
            b.cnt AS cnt_batch,
            ABS(s.cnt - b.cnt) / b.cnt * 100 AS pct_diff,
            s.proc_time_ms AS latency_ms
        FROM 
            stream_window_stats s
        JOIN 
            batch_window_stats b 
        ON 
            s.window_start = b.window_start AND
            s.hashtag = b.hashtag
        ORDER BY 
            s.window_start, pct_diff DESC
        """
        
        logger.info("Executing comparison query")
        cursor.execute(query)
        rows = cursor.fetchall()
        
        # Convert to DataFrame
        df = pd.DataFrame(rows)
        
        if df.empty:
            logger.warning("No comparison data found")
            return None
            
        # Save results to MySQL comparison_metrics table
        save_comparison_to_mysql(conn, df)
        
        return df
        
    except Exception as e:
        logger.error(f"Error getting comparison data: {e}")
        return None
    finally:
        if cursor:
            cursor.close()

def save_comparison_to_mysql(conn, df):
    """Save comparison results to MySQL table."""
    try:
        cursor = conn.cursor()
        
        # Truncate the table first
        cursor.execute("TRUNCATE TABLE comparison_metrics")
        
        # Insert data
        insert_query = """
        INSERT INTO comparison_metrics 
        (window_start, hashtag, cnt_stream, cnt_batch, pct_diff, latency_ms)
        VALUES (%s, %s, %s, %s, %s, %s)
        """
        
        for _, row in df.iterrows():
            cursor.execute(insert_query, (
                row['window_start'],
                row['hashtag'],
                row['cnt_stream'],
                row['cnt_batch'],
                row['pct_diff'],
                row['latency_ms']
            ))
        
        conn.commit()
        logger.info(f"Saved {len(df)} comparison records to MySQL")
        
    except Exception as e:
        logger.error(f"Error saving comparison data to MySQL: {e}")
        conn.rollback()
    finally:
        if cursor:
            cursor.close()

def generate_csv_report(df):
    """Generate CSV report from comparison data."""
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_path = os.path.join(OUTPUT_DIR, f"comparison_report_{timestamp}.csv")
        
        df.to_csv(csv_path, index=False)
        logger.info(f"CSV report generated: {csv_path}")
        return csv_path
    except Exception as e:
        logger.error(f"Error generating CSV report: {e}")
        return None

def generate_charts(df):
    """Generate charts for visualization."""
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Set style for charts
        plt.style.use('ggplot')
        
        # 1. Percent Difference Distribution
        plt.figure(figsize=(10, 6))
        plt.hist(df['pct_diff'], bins=20, alpha=0.7, color='blue')
        plt.axvline(1.0, color='red', linestyle='dashed', linewidth=2, label='1% Error Threshold')
        plt.title('Distribution of Percent Differences between Streaming and Batch Results')
        plt.xlabel('Percent Difference (%)')
        plt.ylabel('Count')
        plt.legend()
        percent_diff_chart = os.path.join(OUTPUT_DIR, f"percent_diff_dist_{timestamp}.png")
        plt.savefig(percent_diff_chart, dpi=300, bbox_inches='tight', facecolor='white')
        plt.close()
        
        # 2. Top 10 Hashtags Comparison (Stream vs Batch)
        # Get top 10 hashtags by batch count
        top_hashtags = df.sort_values('cnt_batch', ascending=False).head(10)
        
        plt.figure(figsize=(12, 8))
        x = range(len(top_hashtags))
        width = 0.35
        
        plt.bar([i - width/2 for i in x], top_hashtags['cnt_stream'], width, label='Streaming', color='blue', alpha=0.7)
        plt.bar([i + width/2 for i in x], top_hashtags['cnt_batch'], width, label='Batch', color='green', alpha=0.7)
        
        plt.xlabel('Hashtag')
        plt.ylabel('Count')
        plt.title('Top 10 Hashtags: Streaming vs Batch Counts')
        plt.xticks(x, top_hashtags['hashtag'], rotation=45, ha='right')
        plt.legend()
        plt.tight_layout()
        
        top_hashtags_chart = os.path.join(OUTPUT_DIR, f"top_hashtags_comparison_{timestamp}.png")
        plt.savefig(top_hashtags_chart, dpi=300, bbox_inches='tight', facecolor='white')
        plt.close()
        
        # 3. Latency Distribution
        plt.figure(figsize=(10, 6))
        plt.hist(df['latency_ms'] / 1000, bins=20, alpha=0.7, color='purple')  # Convert to seconds
        plt.axvline(5.0, color='red', linestyle='dashed', linewidth=2, label='5s Latency Target')
        plt.title('Distribution of Processing Latency')
        plt.xlabel('Latency (seconds)')
        plt.ylabel('Count')
        plt.legend()
        
        latency_chart = os.path.join(OUTPUT_DIR, f"latency_dist_{timestamp}.png")
        plt.savefig(latency_chart, dpi=300, bbox_inches='tight', facecolor='white')
        plt.close()
        
        logger.info(f"Charts generated in {OUTPUT_DIR}")
        
        return {
            'percent_diff': percent_diff_chart,
            'top_hashtags': top_hashtags_chart,
            'latency': latency_chart
        }
        
    except Exception as e:
        logger.error(f"Error generating charts: {e}")
        return None

def analyze_results(df):
    """Analyze the comparison results and print summary statistics."""
    try:
        # Calculate summary statistics
        mean_pct_diff = df['pct_diff'].mean()
        median_pct_diff = df['pct_diff'].median()
        max_pct_diff = df['pct_diff'].max()
        
        # Calculate percentage of windows that meet the 1% error threshold
        windows_within_threshold = (df['pct_diff'] <= 1.0).mean() * 100
        
        # Latency statistics (convert from ms to seconds)
        mean_latency = df['latency_ms'].mean() / 1000
        median_latency = df['latency_ms'].median() / 1000
        max_latency = df['latency_ms'].max() / 1000
        
        # Percentage of windows that meet the 5s latency target
        latency_within_target = (df['latency_ms'] <= 5000).mean() * 100
        
        # Print summary report
        logger.info("\n" + "="*50)
        logger.info("COMPARISON ANALYSIS REPORT")
        logger.info("="*50)
        logger.info(f"Total windows analyzed: {len(df)}")
        logger.info("\nACCURACY METRICS:")
        logger.info(f"Mean percent difference: {mean_pct_diff:.2f}%")
        logger.info(f"Median percent difference: {median_pct_diff:.2f}%")
        logger.info(f"Maximum percent difference: {max_pct_diff:.2f}%")
        logger.info(f"Windows within 1% error threshold: {windows_within_threshold:.2f}%")
        logger.info("\nLATENCY METRICS:")
        logger.info(f"Mean latency: {mean_latency:.2f}s")
        logger.info(f"Median latency: {median_latency:.2f}s")
        logger.info(f"Maximum latency: {max_latency:.2f}s")
        logger.info(f"Windows within 5s latency target: {latency_within_target:.2f}%")
        logger.info("="*50)
        
        # Create a summary dictionary
        summary = {
            'windows_count': len(df),
            'mean_pct_diff': mean_pct_diff,
            'median_pct_diff': median_pct_diff,
            'max_pct_diff': max_pct_diff,
            'windows_within_threshold': windows_within_threshold,
            'mean_latency': mean_latency,
            'median_latency': median_latency,
            'max_latency': max_latency,
            'latency_within_target': latency_within_target
        }
        
        return summary
        
    except Exception as e:
        logger.error(f"Error analyzing results: {e}")
        return None

def main():
    """Main entry point for comparison analysis."""
    logger.info("Starting comparison analysis")
    
    # Connect to MySQL
    conn = connect_to_mysql()
    
    try:
        # Get comparison data
        df = get_comparison_data(conn)
        
        if df is None or df.empty:
            logger.warning("No data available for comparison. Make sure both streaming and batch jobs have run.")
            return
        
        # Generate CSV report
        csv_path = generate_csv_report(df)
        
        # Generate charts
        chart_paths = generate_charts(df)
        
        # Analyze results
        summary = analyze_results(df)
        
        # Save summary to JSON
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        summary_path = os.path.join(OUTPUT_DIR, f"summary_{timestamp}.json")
        
        with open(summary_path, 'w') as f:
            json.dump(summary, f, indent=4)
        
        logger.info(f"Comparison analysis completed. Results saved to {OUTPUT_DIR}")
        
    except Exception as e:
        logger.error(f"Error in comparison analysis: {e}")
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    main() 