#!/usr/bin/env python3
"""
Tweet Producer - Generates fake tweets and publishes to Kafka
"""
import json
import random
import time
import uuid
from datetime import datetime
import logging
import os
import sys

from faker import Faker
from kafka import KafkaProducer
import psutil

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Kafka configuration
KAFKA_BROKER = os.getenv('KAFKA_BROKER', 'localhost:9092')
KAFKA_TOPIC = 'raw_feed'

# Tweet generation config
TWEETS_PER_SECOND = int(os.getenv('TWEETS_PER_SECOND', 100))
SLEEP_TIME = 1.0 / TWEETS_PER_SECOND

# Common hashtags for generating fake tweets
HASHTAGS = [
    "technology", "AI", "ML", "data", "bigdata", "analytics", "cloud", 
    "programming", "python", "java", "coding", "developer", "software",
    "machinelearning", "datascience", "spark", "hadoop", "kafka",
    "streaming", "database", "mysql", "sql", "nosql", "iot", "web"
]

# Languages to use (primarily English)
LANGUAGES = ["en", "en", "en", "en", "es", "fr", "de", "it", "pt"]

class TweetProducer:
    """Generates fake tweets and publishes them to Kafka."""
    
    def __init__(self):
        self.fake = Faker()
        self.producer = KafkaProducer(
            bootstrap_servers=KAFKA_BROKER,
            value_serializer=lambda v: json.dumps(v).encode('utf-8'),
            retries=5
        )
        self.connect_to_kafka()
        
    def connect_to_kafka(self):
        """Ensure connection to Kafka broker."""
        retry_count = 0
        max_retries = 10
        connected = False
        
        while not connected and retry_count < max_retries:
            try:
                logger.info(f"Connecting to Kafka broker at {KAFKA_BROKER}")
                # Test connection by sending a dummy message
                self.producer.send('test', {'test': 'connection'})
                self.producer.flush()
                connected = True
                logger.info("Successfully connected to Kafka")
            except Exception as e:
                retry_count += 1
                logger.warning(f"Failed to connect to Kafka: {e}")
                logger.info(f"Retrying in 5 seconds... (Attempt {retry_count}/{max_retries})")
                time.sleep(5)
        
        if not connected:
            logger.error("Failed to connect to Kafka after maximum retries")
            sys.exit(1)
    
    def generate_tweet(self):
        """Generate a fake tweet with hashtags."""
        # Generate random tweet content
        num_hashtags = random.randint(1, 5)
        hashtags = random.sample(HASHTAGS, num_hashtags)
        
        # Create tweet text with hashtags
        tweet_base = self.fake.text(max_nb_chars=200)
        hashtag_text = ' '.join([f"#{tag}" for tag in hashtags])
        text = f"{tweet_base} {hashtag_text}"
        
        # Create tweet data structure
        tweet = {
            'tweet_id': str(uuid.uuid4()),
            'text': text,
            'author': self.fake.user_name(),
            'created_at': datetime.now().isoformat(),
            'lang': random.choice(LANGUAGES),
            'fetched_at': datetime.now().isoformat(),
            'hashtags': hashtags
        }
        
        return tweet
    
    def produce_tweets(self, duration=None):
        """
        Continuously produce fake tweets at the specified rate.
        
        Args:
            duration: Optional duration in seconds to run producer
        """
        count = 0
        start_time = time.time()
        end_time = start_time + duration if duration else None
        
        try:
            while not end_time or time.time() < end_time:
                tweet = self.generate_tweet()
                
                # Publish tweet to Kafka
                self.producer.send(KAFKA_TOPIC, tweet)
                count += 1
                
                # Log progress periodically
                if count % 1000 == 0:
                    elapsed = time.time() - start_time
                    rate = count / elapsed if elapsed > 0 else 0
                    cpu_percent = psutil.cpu_percent()
                    mem_percent = psutil.virtual_memory().percent
                    logger.info(f"Produced {count} tweets ({rate:.2f}/s). CPU: {cpu_percent}%, Mem: {mem_percent}%")
                
                # Sleep to maintain desired rate
                time.sleep(SLEEP_TIME)
                
        except KeyboardInterrupt:
            logger.info("Producer stopped by user")
        finally:
            # Ensure all messages are sent before exiting
            self.producer.flush()
            logger.info(f"Producer finished. Total tweets produced: {count}")

if __name__ == "__main__":
    logger.info(f"Starting tweet producer with rate of {TWEETS_PER_SECOND} tweets/second")
    producer = TweetProducer()
    producer.produce_tweets() 