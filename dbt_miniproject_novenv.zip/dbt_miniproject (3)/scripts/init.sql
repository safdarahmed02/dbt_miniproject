-- Create the database
CREATE DATABASE IF NOT EXISTS dbt_analytics;
USE dbt_analytics;

-- Create tables according to the requirements
CREATE TABLE IF NOT EXISTS tweet_raw (
    tweet_id VARCHAR(255) PRIMARY KEY,
    text TEXT NOT NULL,
    author VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL,
    lang VARCHAR(10) NOT NULL,
    fetched_at TIMESTAMP NOT NULL,
    INDEX idx_created_at (created_at)
);

CREATE TABLE IF NOT EXISTS stream_window_stats (
    window_start TIMESTAMP,
    window_end TIMESTAMP,
    hashtag VARCHAR(255),
    cnt INT NOT NULL,
    avg_len FLOAT NOT NULL,
    proc_time_ms BIGINT NOT NULL,
    PRIMARY KEY (window_start, hashtag),
    INDEX idx_window (window_start, window_end)
);

CREATE TABLE IF NOT EXISTS batch_window_stats (
    window_start TIMESTAMP,
    window_end TIMESTAMP,
    hashtag VARCHAR(255),
    cnt INT NOT NULL,
    avg_len FLOAT NOT NULL,
    run_date TIMESTAMP NOT NULL,
    PRIMARY KEY (window_start, hashtag),
    INDEX idx_window (window_start, window_end),
    INDEX idx_run_date (run_date)
);

CREATE TABLE IF NOT EXISTS comparison_metrics (
    window_start TIMESTAMP,
    hashtag VARCHAR(255),
    cnt_stream INT NOT NULL,
    cnt_batch INT NOT NULL,
    pct_diff FLOAT NOT NULL,
    latency_ms BIGINT NOT NULL,
    PRIMARY KEY (window_start, hashtag),
    INDEX idx_pct_diff (pct_diff)
);

-- Create a user with necessary privileges
CREATE USER IF NOT EXISTS 'dbt_user'@'%' IDENTIFIED BY 'dbt_password';
GRANT ALL PRIVILEGES ON dbt_analytics.* TO 'dbt_user'@'%';
FLUSH PRIVILEGES; 