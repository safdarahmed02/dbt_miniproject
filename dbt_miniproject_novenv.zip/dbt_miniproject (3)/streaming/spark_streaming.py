#!/usr/bin/env python3
"""
Spark Structured Streaming job for real-time processing of tweets.
This job reads from Kafka, processes data in 20-minute tumbling windows,
and writes results to MySQL and Kafka.
"""
import json
import os
import time
import logging
from datetime import datetime
import sys

from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, from_json, window, count, avg, explode, 
    split, length, current_timestamp, expr, to_timestamp,
    to_json, struct, lit
)
from pyspark.sql.types import (
    StructType, StructField, StringType, 
    TimestampType, ArrayType
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Configuration
KAFKA_BROKER = os.getenv('KAFKA_BROKER', 'localhost:9092')
KAFKA_TOPIC_IN = 'raw_feed'
KAFKA_TOPIC_OUT = 'proc_feed'
KAFKA_TOPIC_RESULTS = 'results_feed'

# Create checkpoint directory
CHECKPOINT_DIR = os.path.join(os.getcwd(), "checkpoints")
os.makedirs(CHECKPOINT_DIR, exist_ok=True)

# MySQL configuration
MYSQL_URL = "jdbc:mysql://localhost:3306/dbt_analytics"
MYSQL_PROPERTIES = {
    "user": "dbt_user",
    "password": "dbt_password",
    "driver": "com.mysql.cj.jdbc.Driver"
}

# Define 20-minute window duration
WINDOW_DURATION = "20 minutes"

# Define schema for incoming tweets
tweet_schema = StructType([
    StructField("tweet_id", StringType(), True),
    StructField("text", StringType(), True),
    StructField("author", StringType(), True),
    StructField("created_at", StringType(), True),
    StructField("lang", StringType(), True),
    StructField("fetched_at", StringType(), True),
    StructField("hashtags", ArrayType(StringType()), True)
])

def create_spark_session():
    """Create and configure Spark Session with necessary packages."""
    return (SparkSession.builder
            .appName("TweetStreamingAnalytics")
            .master("local[*]")  # Use local mode for simplicity
            .config("spark.jars.packages", 
                   "org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.0,"
                   "mysql:mysql-connector-java:8.0.33")
            .config("spark.streaming.stopGracefullyOnShutdown", "true")
            .config("spark.sql.session.timeZone", "UTC")
            .config("spark.executor.memory", "1g")
            .config("spark.driver.memory", "1g")
            .getOrCreate())

def save_raw_tweets(df, epoch_id):
    """Save raw tweets to MySQL."""
    if df.isEmpty():
        return
    
    start_time = time.time()
    
    # Transform the DataFrame to match the table schema
    df_to_save = df.select(
        col("tweet_id"),
        col("text"),
        col("author"),
        col("created_at"),
        col("lang"),
        col("fetched_at")
    )
    
    # Write to MySQL
    try:
        (df_to_save.write
            .jdbc(
                url=MYSQL_URL,
                table="tweet_raw",
                mode="append",
                properties=MYSQL_PROPERTIES
            ))
        
        elapsed = time.time() - start_time
        logger.info(f"Batch {epoch_id}: Saved {df_to_save.count()} tweets to MySQL in {elapsed:.2f}s")
    except Exception as e:
        logger.error(f"Error saving tweets to MySQL: {e}")

def save_window_stats(df, epoch_id):
    """Save windowed statistics to MySQL."""
    if df.isEmpty():
        return
    
    start_time = time.time()
    
    # Write to MySQL
    try:
        (df.write
            .jdbc(
                url=MYSQL_URL,
                table="stream_window_stats",
                mode="append",
                properties=MYSQL_PROPERTIES
            ))
        
        elapsed = time.time() - start_time
        count = df.count()
        logger.info(f"Batch {epoch_id}: Saved {count} window stats to MySQL in {elapsed:.2f}s")
    except Exception as e:
        logger.error(f"Error saving window stats to MySQL: {e}")

def process_streaming_data(spark):
    """Process streaming data from Kafka."""
    try:
        # Read from Kafka
        kafka_stream = (spark
            .readStream
            .format("kafka")
            .option("kafka.bootstrap.servers", KAFKA_BROKER)
            .option("subscribe", KAFKA_TOPIC_IN)
            .option("startingOffsets", "latest")
            .option("failOnDataLoss", "false")
            .load())
        
        # Parse JSON data
        parsed_stream = kafka_stream.select(
            from_json(col("value").cast("string"), tweet_schema).alias("tweet")
        ).select("tweet.*")
        
        # Convert string timestamps to proper timestamp type
        tweets_df = parsed_stream.select(
            col("tweet_id"),
            col("text"),
            col("author"),
            to_timestamp(col("created_at")).alias("created_at"),
            col("lang"),
            to_timestamp(col("fetched_at")).alias("fetched_at"),
            col("hashtags")
        )
        
        # Filter for English tweets primarily (as per requirement)
        english_tweets = tweets_df.filter(col("lang") == "en")
        
        # Save raw tweets to MySQL for batch processing
        query_raw = (english_tweets
            .writeStream
            .foreachBatch(lambda df, epoch_id: save_raw_tweets(df, epoch_id))
            .option("checkpointLocation", os.path.join(CHECKPOINT_DIR, "raw_tweets"))
            .trigger(processingTime="10 seconds")
            .outputMode("append")
            .start())
        
        # Extract hashtags and compute stats
        hashtag_df = (english_tweets
            .select(
                col("tweet_id"),
                col("created_at"),
                explode(col("hashtags")).alias("hashtag"),
                length(col("text")).alias("text_length")
            )
            .filter(col("hashtag").isNotNull())
        )
        
        # Apply windowed aggregations
        windowed_stats = (hashtag_df
            .withWatermark("created_at", "10 minutes")
            .groupBy(
                window(col("created_at"), WINDOW_DURATION),
                col("hashtag")
            )
            .agg(
                count("*").alias("cnt"),
                avg("text_length").alias("avg_len")
            )
            .select(
                col("window.start").alias("window_start"),
                col("window.end").alias("window_end"),
                col("hashtag"),
                col("cnt"),
                col("avg_len"),
                # Use current time in milliseconds modulo a smaller number to ensure it fits in BIGINT
                expr("unix_timestamp() * 1000").cast("long").alias("proc_time_ms")
            )
        )
        
        # Write aggregated stats to MySQL
        query_stats = (windowed_stats
            .writeStream
            .foreachBatch(lambda df, epoch_id: save_window_stats(df, epoch_id))
            .option("checkpointLocation", os.path.join(CHECKPOINT_DIR, "window_stats"))
            .trigger(processingTime="20 seconds")
            .outputMode("update")
            .start())
        
        # Write processed results to Kafka results topic
        query_results = (windowed_stats
            .select(
                to_json(struct("*")).alias("value")
            )
            .writeStream
            .format("kafka")
            .option("kafka.bootstrap.servers", KAFKA_BROKER)
            .option("topic", KAFKA_TOPIC_RESULTS)
            .option("checkpointLocation", os.path.join(CHECKPOINT_DIR, "results"))
            .trigger(processingTime="20 seconds")
            .outputMode("update")
            .start())
        
        return [query_raw, query_stats, query_results]
    
    except Exception as e:
        logger.error(f"Error setting up streaming: {e}")
        raise

def main():
    """Main entry point for the Spark Streaming job."""
    logger.info("Starting Spark Streaming job for tweet analytics")
    
    spark = None
    try:
        # Create Spark session
        spark = create_spark_session()
        
        # Process streaming data
        queries = process_streaming_data(spark)
        
        # Wait for all queries to terminate
        logger.info("Streaming queries started, waiting for termination...")
        for query in queries:
            query.awaitTermination()
            
    except KeyboardInterrupt:
        logger.info("Stopping Spark Streaming job due to user interrupt")
    except Exception as e:
        logger.error(f"Error in Spark Streaming job: {e}")
    finally:
        if spark:
            logger.info("Stopping Spark session")
            spark.stop()
            logger.info("Spark session stopped")

if __name__ == "__main__":
    main() 